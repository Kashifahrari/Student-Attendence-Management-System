CREATE TABLE `tb_data` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `USN` varchar(50) NOT NULL,
  `Phone Number` varchar(50) NOT NULL,
  `age` varchar(50) NOT NULL,
  `Academic Session` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `languages` varchar(50) NOT NULL,
  `Parent's Name` varchar(50) NOT NULL,
  `Parent's Phone` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `tb_data` (`id`, `name`,`USN`,`Phone Number`, `age`,`Academic Session`, `country`, `gender`, `languages`,`Parent's Name`,`Parent's Phone`) VALUES
(9, 'd','1aj21cs00','9876543211', '12','2021-2025','India', 'Male', 'English,Chinese,Spanish,','MR. Sam', '9876543211');

ALTER TABLE `tb_data`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `tb_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;
