<?php
require 'connection.php';

if(isset($_POST["submit"])){
  $name = $_POST["name"];
  $usn = $_POST["USN"];
  $phone_number = $_POST["Phone_Number"];
  $age = $_POST["age"];
  $academic_session = $_POST["Academic_Session"];
  $country = $_POST["country"];
  $gender = $_POST["gender"];
  $parent_name = $_POST["Parents_Name"];
  $parent_phone = $_POST["Parents_Phone"];

  $languages = isset($_POST["languages"]) ? $_POST["languages"] : [];
  $language = implode(",", $languages);

  $query = "INSERT INTO tb_data (name, `USN`, `Phone Number`, age, `Academic Session`, country, gender, languages, `Parent's Name`, `Parent's Phone`) VALUES ('$name', '$usn', '$phone_number', '$age', '$academic_session', '$country', '$gender', '$language', '$parent_name', '$parent_phone')";
  mysqli_query($conn, $query);

  if(mysqli_affected_rows($conn) > 0) {
    echo "<script>alert('Data Inserted Successfully');</script>";
  } else {
    echo "<script>alert('Data Insertion Failed');</script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="utf-8">
  <title>Insert Data</title>
  <style media="screen">
    body {
      font-family: Arial, sans-serif;
      background-color: #f4f4f4;
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .form-container {
      background: #fff;
      padding: 20px 40px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 500px;
    }

    h2 {
      text-align: center;
      margin-bottom: 20px;
    }

    label {
      display: block;
      margin: 10px 0 5px;
    }

    input[type="text"],
    input[type="number"],
    select {
      width: 100%;
      padding: 8px;
      margin-bottom: 10px;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
    }

    input[type="radio"],
    input[type="checkbox"] {
      margin-right: 10px;
    }

    .gender, .languages {
      margin-bottom: 10px;
    }

    .gender label, .languages label {
      display: inline-block;
      margin-right: 10px;
    }

    button[type="submit"] {
      background-color: #28a745;
      color: #fff;
      border: none;
      padding: 10px 20px;
      border-radius: 4px;
      cursor: pointer;
      width: 100%;
    }

    button[type="submit"]:hover {
      background-color: #218838;
    }
  </style>
</head>
<body>
  <div class="form-container">
    <h2>Insert Data</h2>
    <form action="" method="post" autocomplete="off">
      <label for="name">Name</label>
      <input type="text" name="name" id="name" required>

      <label for="usn">USN</label>
      <input type="text" name="USN" id="usn" required>

      <label for="phone_number">Phone Number</label>
      <input type="number" name="Phone_Number" id="phone_number" required>

      <label for="age">Age</label>
      <input type="number" name="age" id="age" required>

      <label for="academic_session">Academic Session</label>
      <input type="text" name="Academic_Session" id="academic_session" required>

      <label for="country">Country</label>
      <select name="country" id="country" required>
        <option value="" selected hidden>Select Country</option>
        <option value="USA">USA</option>
        <option value="England">UK</option>
        <option value="India">India</option>
        <option value="Nepal">Nepal</option>
      </select>

      <div class="gender">
        <label for="gender">Gender</label>
        <input type="radio" name="gender" value="Male" required> Male
        <input type="radio" name="gender" value="Female"> Female
      </div>

      <div class="languages">
        <label for="languages">Languages</label>
        <input type="checkbox" name="languages[]" value="English"> English
        <input type="checkbox" name="languages[]" value="Chinese"> Chinese
        <input type="checkbox" name="languages[]" value="Spanish"> Spanish
      </div>

      <label for="parents_name">Parent's Name</label>
      <input type="text" name="Parents_Name" id="parents_name" required>

      <label for="parents_phone">Parent's Phone</label>
      <input type="number" name="Parents_Phone" id="parents_phone" required>

      <br>
      <button type="submit" name="submit">Submit</button>
    </form>
  </div>
</body>
</html>
