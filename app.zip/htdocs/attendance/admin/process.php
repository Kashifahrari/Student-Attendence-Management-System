<?php
// Include database connection
include('connect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action']) && $_POST['action'] == 'Add Student') {
        // Collect and sanitize student data
        $st_id = mysqli_real_escape_string($conn, $_POST['st_id']);
        $st_name = mysqli_real_escape_string($conn, $_POST['st_name']);
        $st_dept = mysqli_real_escape_string($conn, $_POST['st_dept']);
        $st_batch = mysqli_real_escape_string($conn, $_POST['st_batch']);
        $st_sem = mysqli_real_escape_string($conn, $_POST['st_sem']);
        $st_email = mysqli_real_escape_string($conn, $_POST['st_email']);

        // Adjust column names according to your database schema
        $sql = "INSERT INTO students (st_id, st_name, st_dept, st_batch, st_sem, st_email) VALUES ('$st_id', '$st_name', '$st_dept', '$st_batch', '$st_sem', '$st_email')";
        if (mysqli_query($conn, $sql)) {
            $success_msg = "Student added successfully!";
        } else {
            $error_msg = "Error adding student: " . mysqli_error($conn);
        }
    }

    if (isset($_POST['action']) && $_POST['action'] == 'Add Teacher') {
        // Collect and sanitize teacher data
        $tc_id = mysqli_real_escape_string($conn, $_POST['tc_id']);
        $tc_name = mysqli_real_escape_string($conn, $_POST['tc_name']);
        $tc_dept = mysqli_real_escape_string($conn, $_POST['tc_dept']);
        $tc_email = mysqli_real_escape_string($conn, $_POST['tc_email']);
        $tc_course = mysqli_real_escape_string($conn, $_POST['tc_course']);

        // Adjust column names according to your database schema
        $sql = "INSERT INTO teachers (tc_id, tc_name, tc_dept, tc_email, tc_course) VALUES ('$tc_id', '$tc_name', '$tc_dept', '$tc_email', '$tc_course')";
        if (mysqli_query($conn, $sql)) {
            $success_msg = "Teacher added successfully!";
        } else {
            $error_msg = "Error adding teacher: " . mysqli_error($conn);
        }
    }

    // Redirect back to the index page with success or error message
    header("Location: index.php");
    exit();
}

mysqli_close($conn);
?>