<?php
include ('connect.php');

if(isset($_POST['login']))
{
    //start of try block
    try {
        //checking empty fields
        if(empty($_POST['username'])) {
            throw new Exception("Username is required!");
        }
        if(empty($_POST['password'])) {
            throw new Exception("Password is required!");
        }

        // Sanitizing inputs to prevent SQL Injection
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);
        $type = mysqli_real_escape_string($conn, $_POST['type']);

        //checking login info into database
        $row = 0;
        $query = "SELECT * FROM admininfo WHERE username='$username' AND password='$password' AND type='$type'";
        $result = mysqli_query($conn, $query);

        if (!$result) {
            throw new Exception('Query failed: ' . mysqli_error($conn));
        }

        $row = mysqli_num_rows($result);

        if($row > 0 && $type == 'teacher') {
            session_start();
            $_SESSION['name'] = "oasis";
            header('Location: teacher/index.php');
            exit();
        } elseif($row > 0 && $type == 'student') {
            session_start();
            $_SESSION['name'] = "oasis";
            header('Location: student/index.php');
            exit();
        } elseif($row > 0 && $type == 'admin') {
            session_start();
            $_SESSION['name'] = "oasis";
            header('Location: admin/index.php');
            exit();
        } else {
            throw new Exception("Username, Password, or Role is wrong, try again!");
        }
    } catch(Exception $e) {
        $error_msg = $e->getMessage();
    }
    //end of try-catch
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cambridge Institute Of Technology Student Attendance System</title>
    <style>
        /* Resetting some default styles */
        body, h1, p, label, input, button {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* General body styling */
        body {
            font-family: 'Georgia', serif;
            background-color: #455d7a; /* Light yellow background */
            color: #333;
            line-height: 1.6;
            padding: 20px;
        }

        /* Header styling */
        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            border-radius: 5px;
        }

        header h1 {
            font-size: 24px;
            text-align: center;
            margin: 0;
        }

        /* Form container styling */
        .content {
            background:#e3e3e3;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            max-width: 600px;
            margin: auto;
        }

        /* Form element styling */
        .form-horizontal .form-group {
            margin-bottom: 15px;
        }

        .form-horizontal .control-label {
            font-weight: bold;
            text-align: right;
            padding-right: 15px;
        }

        .form-horizontal .form-control {
            border: 1px solid #ccc;
            border-radius: 4px;
            padding: 10px;
            width: 100%;
        }

        .form-horizontal .form-control:focus {
            border-color: #5bc0de;
            box-shadow: 0 1px 1px rgba(0,0,0,0.075) inset;
        }

        /* Button styling */
        .btn {
            font-size: 16px;
            padding: 10px 20px;
            border-radius: 4px;
        }

        .btn-primary {
            background-color: #f2f2f2;
            border: 1px solid #46b8da;
            color: black;
        }

        .btn-primary:hover {
            background-color: #31b0d5;
            border-color: #269abc;
        }

        /* Alert message styling */
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }

        .alert-danger {
            color: #a94442;
            background-color: #f2dede;
            border-color: #ebccd1;
        }

        /* Links styling */
        a {
            color: #5bc0de;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
        #dem{
            color:  #eaf6f6;
        }
    </style>
</head>
<body>
    <center>
    <header>
        <h1>Student Attendance System</h1>
    </header>

    <h1 id="dem">Login</h1>

    <?php
    //printing error message
    if(isset($error_msg)) {
        echo "<div class='alert alert-danger'>$error_msg</div>";
    }
    ?>

    <div class="content">
        <div class="row">
            <form method="post" class="form-horizontal col-md-6 col-md-offset-3">
                <div class="form-group">
                    <label for="input1" class="col-sm-3 control-label">Username</label>
                    <div class="col-sm-7">
                        <input type="text" name="username" class="form-control" id="input1" placeholder="your username" />
                    </div>
                </div>

                <div class="form-group">
                    <label for="input1" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-7">
                        <input type="password" name="password" class="form-control" id="input1" placeholder="your password" />
                    </div>
                </div>

                <div class="form-group" class="radio">
                    <label for="input1" class="col-sm-3 control-label">Role</label>
                    <div class="col-sm-7">
                        <label>
                            <input type="radio" name="type" id="optionsRadios1" value="student" > Student
                        </label>
                        <label>
                            <input type="radio" name="type" id="optionsRadios1" value="teacher"> Teacher
                        </label>
                        <label>
                            <input type="radio" name="type" id="optionsRadios1" value="admin" checked> Admin
                        </label>
                    </div>
                </div>

                <input type="submit" class="btn btn-primary col-md-3 col-md-offset-7" value="Login" name="login" />
            </form>
        </div>
    </div>

    <br><br>
    <p ><strong style="color:#333;">Have you forgotten your password? <a style="color:#eaf6f6;"  href="reset.php">Reset here.</a></strong></p>
    <p ><strong style="color:#333;">If you don't have an account, <a style="color:#eaf6f6 ;" href="signup.php">Signup</a> here</strong></p>
    </center>
</body>
</html>
