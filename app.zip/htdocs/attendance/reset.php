<?php
include('connect.php');

if (isset($_POST['reset'])) {
    $email = $_POST['email'];

    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_msg = "Invalid email format.";
    } else {
        // Sanitize email
        $email = mysqli_real_escape_string($conn, $email);

        // Query to check if email exists
        $query = "SELECT password FROM admininfo WHERE email = '$email'";
        $result = mysqli_query($conn, $query);

        if (!$result) {
            $error_msg = "Database query failed: " . mysqli_error($conn);
        } else {
            $row = mysqli_num_rows($result);

            if ($row == 0) {
                $error_msg = "Email is not associated with any account. Contact OAMS 1.0";
            } else {
                // Fetch and display password recovery key
                $data = mysqli_fetch_assoc($result);
                $password = $data['password'];
                $success_msg = "<strong>
                <p style='text-align: left;'>Hi there!<br>You requested a password recovery. You may <a href='index.php'>Login here</a> and enter this key as your password to login. Recovery key: <mark>$password</mark><br>Regards,<br>Online Attendance Management System 1.0</p></strong>";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>Cambridge Institute Of Technology Student Attendance System</title>
<meta charset="UTF-8">
  <link rel="stylesheet" type="text/css" href="css/main.css">
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <!-- Optional theme -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css">
  <link rel="stylesheet" href="styles.css">
  <!-- Latest compiled and minified JavaScript -->
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
        /* Resetting some default styles */
        body, h1, p, label, input, button {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* General body styling */
        body {
            font-family: 'Georgia', serif;
            background-color: #007bff; /* Blue background color */
            color: #fff;
            line-height: 1.6;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
        }

        /* Header styling */
        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
            margin-bottom: 20px;
            width: 100%;
            text-align: center;
        }

        /* Form container styling */
        .content {
            background: #fff;
            color: #333;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            max-width: 600px;
            width: 130%;
        }

        /* Form element styling */
        .form-horizontal .form-group {
            margin-bottom: 20px;
        }

        .form-horizontal .control-label {
            font-weight: bold;
            text-align: left;
            padding-right: 15px;
            font-size: 16px;
        }

        .form-horizontal .form-control {
            border: 1px solid #ccc;
            border-radius: 6px;
            padding: 12px;
            width: 100%;
            font-size: 16px;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        .form-horizontal .form-control:focus {
            border-color: #007bff;
            box-shadow: 0 0 8px rgba(0,123,255,0.5);
            outline: none;
        }

        /* Button styling */
        .btn {
            font-size: 16px;
            padding: 12px 24px;
            padding-right: 35px;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease, border-color 0.3s ease;
        }

        .btn-primary {
             background-color: #007bff; */
            border: 1px solid #0056b3;
            color: #fff;
            
        }

        .btn-primary:hover {
             background-color: #0056b3; */
            border-color: #004494;
        }

        /* Alert message styling */
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 6px;
            font-size: 16px;
        }

        .alert-success {
            color: #3c763d;
            background-color: #dff0d8;
            border-color: #d0e9c6;
        }

        .alert-danger {
            color: #a94442;
            background-color: #f2dede;
            border-color: #ebccd1;
        }

        /* Links styling */
        a {
            color: #007bff;
            text-decoration: none;
            transition: color 0.3s ease;
        }

        a:hover {
            text-decoration: underline;
            color: #0056b3;
        }
        .aa{
          margin-left: 33em;
        }
        #goo{
          margin-left: 06em;
          text-align: center;
        }
        .pra{
       align-items: center;
        }
        .form-control{
          margin-left:2rem; ;
        }
        #we{
          
        }
    </style>
</head>
<body>

<header>
  <h1>Student Attendance System</h1>
  <div class="navbar">
    <a class="aa"href="index.php">Login</a>
  </div>
</header>

<center>
<div class="content">
    <div class="row">
        <form method="post" id="we" class="form-horizontal col-md-6 col-md-offset-3">
            <h3 id="pra">Recover your password</h3>
         <br>
            <div class="form-group">
                <label for="input1" class="col-sm-2 control-label">Email</label>
                <div class="col-sm-10">
                    <input type="email" name="email" class="form-control" id="input1" placeholder="your email" />
                </div>
            </div>

            <input id="goo" type="submit" class="btn btn-primary col-md-2 col-md-offset-10" value="Go" name="reset" />
        </form>

        <br>

        <?php
            if (isset($error_msg)) {
                echo "<div class='alert alert-danger'>$error_msg</div>";
            }
            if (isset($success_msg)) {
                echo "<div class='alert alert-success'>$success_msg</div>";
            }
        ?>
    </div>
</div>
</center>

</body>
</html>
